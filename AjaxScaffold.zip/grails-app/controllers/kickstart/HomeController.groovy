package kickstart

class HomeController {

	def index() {
	}
}
