@artifact.package@/**
 * @artifact.name@
 * A controller class handles incoming web requests and performs actions such as redirects, rendering views and so on.
 */
class @artifact.name@ {

	static scaffold = true
	
	//	def index () { }
	
}
