@artifact.package@/**
 * @artifact.name@
 * A taglib library provides a set of reusable tags to help rendering the views.
 */
class @artifact.name@ {
    static defaultEncodeAs = [taglib:'html']
    //static encodeAsForTags = [tagName: [taglib:'html'], otherTagName: [taglib:'none']]
}
