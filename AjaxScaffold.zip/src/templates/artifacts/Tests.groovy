@artifact.package@/**
 * @artifact.name@
 * A unit test class is used to test individual methods or blocks of code without considering the surrounding infrastructure
 */
@import grails.test.*

class @artifact.name@ extends @artifact.superclass@ {
    protected void setUp() {
        super.setUp()
    }

    protected void tearDown() {
        super.tearDown()
    }

    void testSomething() {

    }
}
