@artifact.package@import grails.transaction.Transactional

/**
 * @artifact.name@
 * A service class encapsulates the core business logic of a Grails application
 */
@Transactional
class @artifact.name@ {

    def serviceMethod() {

    }
}
